# from odoo import models,fields,api
#
# class stock_move_line(models.Model):
#
#     _inherit = 'stock.move.line'
#
#     # @api.model
#     # def create(self, vals_list):
#     #     print(vals_list)
#     #     return super(stock_move_line, self).create(vals_list)